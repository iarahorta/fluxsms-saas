import re
import time
import threading
import state
from config import SERVICOS, SERVICOS_ORDEM, MEMORIAS_HUAWEI, MEMORIAS_PADRAO, PREFIXO_CCID, SMS_POLL_INTERVAL
from modems.core import (
    abrir_serial_simples, enviar_comando, detectar_huawei,
    ler_sms_completo, _limpar_todos_sms, configurar_sms_compatibilidade
)
from modems.detection import parsear_ccid
from db.database import salvar_sms_historico
from db.cloud_sync import sync_sms_to_cloud

def detectar_servico(texto_sms):
    texto_lower = texto_sms.lower()
    for srv_id in SERVICOS_ORDEM:
        srv = SERVICOS[srv_id]
        if any(kw in texto_lower for kw in srv["keywords"]):
            match = re.search(srv["codigo_regex"], texto_sms, re.IGNORECASE)
            if match:
                try: codigo = match.group(1) + match.group(2)
                except IndexError: codigo = match.group(1)
                return srv["nome"], codigo
    return None, None

def monitorar_sms(porta, numero):
    grid = state.mapa_usb.get(porta, {}).get("grid", "??")
    print(f"\n" + "═"*60)
    print(f" 🔍 MONITORAMENTO BRUTO: {porta} [{grid}]")
    print(f" 📂 MOSTRANDO TODA A CAIXA DE ENTRADA (TODAS AS MEMÓRIAS)")
    print(f" (Pressione Ctrl+C para VOLTAR ao menu principal)")
    print("═"*60 + "\n")

    try:
        ser = abrir_serial_simples(porta)
        if not ser: return
        with ser:
            enviar_comando(ser, "AT+CMGF=1")
            is_huawei = detectar_huawei(ser)
            memorias = MEMORIAS_HUAWEI if is_huawei else MEMORIAS_PADRAO
            _limpar_todos_sms(ser, memorias)
            configurar_sms_compatibilidade(ser)

            ultima_qtd = -1
            while True:
                lista = ler_sms_completo(ser, is_huawei)
                qtd_atual = len(lista)
                if qtd_atual != ultima_qtd:
                    if qtd_atual > 0:
                        print(f"\n 📬 MENSAGENS ENCONTRADAS ({qtd_atual}) - {time.strftime('%H:%M:%S')}")
                        for m in lista:
                            texto = m.get('texto', '').strip()
                            servico, codigo = detectar_servico(texto)
                            if not servico or not codigo:
                                servico = "Desconhecido"
                                codigo = texto[:15] + "..."
                            item = {"servico": servico, "codigo": codigo, "numero": numero, "porta": porta, "grid": grid, "timestamp": time.strftime('%H:%M:%S')}
                            with state.fila_lock:
                                if not any(x["numero"] == numero and x["codigo"] == codigo for x in state.fila_codigos):
                                    state.fila_codigos.append(item)
                            try: salvar_sms_historico(numero, porta, servico, codigo, texto)
                            except: pass
                            # Sincroniza SMS com a nuvem (Ativação)
                            sync_sms_to_cloud(numero, texto)
                            print(f" [#] ID: {m.get('index')} | {servico}: {codigo}")
                    ultima_qtd = qtd_atual
                time.sleep(3)
    except KeyboardInterrupt: pass

def thread_monitor_individual(porta, numero, stop_evt):
    grid = state.mapa_usb.get(porta, {}).get("grid", "??")
    ids_processados = set()
    with state.lock: print(f"\n  [WEB REQUEST] 📥 Iniciando monitoramento individual: {porta} [{grid}] ({numero})")
    try:
        ser = abrir_serial_simples(porta)
        if not ser:
            with state.lock: print(f"  ❌ [WEB REQUEST] Falha ao abrir porta {porta} (Ocupada ou erro)")
            return
        with ser:
            from modems.detection import aguardar_registro
            with state.lock: print(f"  [INFO] Verificando sinal da torre em {porta}...")
            aguardar_registro(ser, porta)
            
            is_huawei = detectar_huawei(ser)
            memorias = MEMORIAS_HUAWEI if is_huawei else MEMORIAS_PADRAO
            enviar_comando(ser, "AT+CMGF=1")
            _limpar_todos_sms(ser, memorias)
            configurar_sms_compatibilidade(ser)
            
            with state.lock: print(f"  [OK] Monitoramento ATIVO na porta {porta}. Aguardando SMS...")
            while not stop_evt.is_set():
                todas_sms = ler_sms_completo(ser, is_huawei, pdu_primario=is_huawei)
                for sms in todas_sms:
                    texto = sms.get("texto", "").strip()
                    if not texto or texto[:80] in ids_processados: continue
                    servico, codigo = detectar_servico(texto)
                    if not servico or not codigo: servico, codigo = "Desconhecido", texto[:15]+"..."
                    item = {"servico": servico, "codigo": codigo, "numero": numero, "porta": porta, "grid": grid, "timestamp": time.strftime('%H:%M:%S')}
                    ids_processados.add(texto[:80])
                    with state.fila_lock:
                        if not any(x["numero"] == numero and x["codigo"] == codigo for x in state.fila_codigos):
                            state.fila_codigos.append(item)
                    try: salvar_sms_historico(numero, porta, servico, codigo, texto)
                    except: pass
                    # Sincroniza SMS com a nuvem (Ativação)
                    sync_sms_to_cloud(numero, texto)
                _limpar_todos_sms(ser, memorias, todas_sms)
                time.sleep(SMS_POLL_INTERVAL)
    except Exception as e:
        with state.lock: print(f"  ❌ [WEB REQUEST] Erro monitorando {porta}: {e}")
    finally:
        with state.monitores_lock:
            if porta in state.monitores_individuais:
                del state.monitores_individuais[porta]
        with state.lock: print(f"  🛑 [WEB REQUEST] Monitoramento encerrado na porta {porta}")

def watch_codigos_porta(porta, numero, ser, ids_processados, is_huawei=False):
    memorias = MEMORIAS_HUAWEI if is_huawei else MEMORIAS_PADRAO
    todas_sms = []
    try:
        todas_sms = ler_sms_completo(ser, is_huawei, pdu_primario=is_huawei)
        for sms in todas_sms:
            texto = sms.get("texto", "").strip()
            if not texto or texto[:80] in ids_processados: continue
            servico, codigo = detectar_servico(texto)
            if not servico or not codigo: servico, codigo = "Desconhecido", texto[:15]+"..."
            item = {"servico": servico, "codigo": codigo, "numero": numero, "porta": porta, "grid": state.mapa_usb.get(porta, {}).get("grid", "??"), "timestamp": time.strftime('%H:%M:%S')}
            ids_processados.add(texto[:80])
            with state.fila_lock: state.fila_codigos.append(item)
            try: salvar_sms_historico(numero, porta, servico, codigo, texto)
            except: pass
    finally:
        _limpar_todos_sms(ser, memorias, todas_sms)

def tarefa_watch_porta(porta, numero):
    ids_processados = set()
    try:
        ser = abrir_serial_simples(porta)
        if not ser: return
        with ser:
            configurar_sms_compatibilidade(ser)
            is_huawei = detectar_huawei(ser)
            while not state.stop_watch.is_set():
                watch_codigos_porta(porta, numero, ser, ids_processados, is_huawei)
                time.sleep(SMS_POLL_INTERVAL)
    except: pass

def watch_all(lista_portas_numeros):
    print(f"\n  👁️ MODO WATCH — Monitorando {len(lista_portas_numeros)} modems...")
    state.stop_watch.clear()
    for porta, numero in lista_portas_numeros:
        threading.Thread(target=tarefa_watch_porta, args=(porta, numero), daemon=True).start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        state.stop_watch.set()
