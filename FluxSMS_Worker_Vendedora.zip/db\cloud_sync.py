import os
import time
import requests
import string
import random
from dotenv import load_dotenv, set_key

# Carrega variáveis de ambiente
load_dotenv()

SUPABASE_URL = os.getenv("SUPABASE_URL")
if SUPABASE_URL and SUPABASE_URL.endswith('/'):
    SUPABASE_URL = SUPABASE_URL[:-1]
SUPABASE_KEY = os.getenv("SUPABASE_SERVICE_KEY") # Usamos service_key para bypassar RLS e gerenciar hardware

_current_polo_id = None

def get_headers():
    return {
        "apikey": SUPABASE_KEY,
        "Authorization": f"Bearer {SUPABASE_KEY}",
        "Content-Type": "application/json",
        "Prefer": "return=representation"
    }

def gerar_chave_aleatoria():
    caracteres = string.ascii_uppercase + string.digits
    aleatorio_1 = ''.join(random.choice(caracteres) for _ in range(9))
    aleatorio_2 = ''.join(random.choice(caracteres) for _ in range(7))
    return f"FLUX_{aleatorio_1}_{aleatorio_2}"

def init_polo():
    """Incializa e registra automaticamente o Polo."""
    global _current_polo_id
    if not SUPABASE_URL or not SUPABASE_KEY:
        print("⚠️ Erro: SUPABASE_URL ou SUPABASE_SERVICE_KEY ausentes no .env!")
        return False
        
    chave = os.getenv("POLO_KEY")
    nome = "Polo Auto"
    
    # Gerar chave local se não houver
    if not chave:
        chave = gerar_chave_aleatoria()
        set_key(".env", "POLO_KEY", chave)
        print(f"🔑 Chave de Polo gerada localmente: {chave}")
        nome = "Polo Pendente (Auto)"

    try:
        headers = get_headers()
        # Busca o polo pela chave
        resp = requests.get(f"{SUPABASE_URL}/rest/v1/polos?chave_acesso=eq.{chave}&select=*", headers=headers)
        
        if resp.status_code == 200 and len(resp.json()) > 0:
            _current_polo_id = resp.json()[0]["id"]
            # Atualiza status
            update_data = {
                "status": "ONLINE",
                "ultima_comunicacao": "now()"
            }
            # PATCH requer Prefer = return=representation se quiser retorno, default é ok para update
            requests.patch(f"{SUPABASE_URL}/rest/v1/polos?id=eq.{_current_polo_id}", json=update_data, headers=headers)
            print(f"📡 Polo [{_current_polo_id[:8]}] conectado com sucesso.")
            return True
        else:
            # Não existe, então vamos criar um
            print(f"➕ Auto-registrando novo Polo no servidor...")
            insert_data = {
                "nome": nome,
                "chave_acesso": chave,
                "status": "ONLINE"
            }
            # POST para criar
            res_insert = requests.post(f"{SUPABASE_URL}/rest/v1/polos", json=insert_data, headers=headers)
            if res_insert.status_code in (200, 201):
                data = res_insert.json()
                if len(data) > 0:
                    _current_polo_id = data[0]["id"]
                    print(f"📡 Polo auto-registrado com ID: {_current_polo_id[:8]}. Já visível no SaaS!")
                    return True
            print(f"⚠️ Erro ao registrar Polo: {res_insert.text}")
            return False
            
    except Exception as e:
        print(f"⚠️ Erro de rede ao conectar Polo: {e}")
        return False

def sync_chip_to_cloud(porta, numero, operadora):
    """Sincroniza o chip diretamente na tabela 'chips' global, visível no web."""
    global _current_polo_id
    if not _current_polo_id or not SUPABASE_URL: return

    try:
        headers = get_headers()
        # Busca se a porta já existe
        resp_get = requests.get(f"{SUPABASE_URL}/rest/v1/chips?porta=eq.{porta}&select=*", headers=headers)
        
        data = {
            "porta": porta,
            "numero": numero,
            "status": "idle" # Força status idle para ficar disponível para SMS
        }
        
        if resp_get.status_code == 200 and len(resp_get.json()) > 0:
            chip_id = resp_get.json()[0]["id"]
            resp_update = requests.patch(f"{SUPABASE_URL}/rest/v1/chips?id=eq.{chip_id}", json=data, headers=headers)
            if resp_update.status_code in (200, 204):
                print(f"  [OK] Chip {numero} enviado para a nuvem com sucesso! (Atualizado na {porta})")
        else:
            resp_insert = requests.post(f"{SUPABASE_URL}/rest/v1/chips", json=data, headers=headers)
            if resp_insert.status_code in (200, 201):
                print(f"  [OK] Chip {numero} enviado para a nuvem com sucesso! (Novo na {porta})")
            else:
                print(f"  ⚠️ Erro inserindo chip: {resp_insert.text}")
                
    except Exception as e:
        print(f"  ⚠️  [CLOUD] Erro de rede ao sincronizar chip: {e}")

def sync_sms_to_cloud(numero, texto):
    """Envia o SMS recebido para a ativação pendente no Supabase."""
    if not SUPABASE_URL: return False

    try:
        headers = get_headers()
        # 1. Busca a ativação mais recente 'waiting' para este número
        resp_act = requests.get(f"{SUPABASE_URL}/rest/v1/activations?phone_number=eq.{numero}&status=eq.waiting&order=created_at.desc&limit=1&select=*", headers=headers)
        
        if resp_act.status_code == 200 and len(resp_act.json()) > 0:
            activation = resp_act.json()[0]
            act_id = activation["id"]
            chip_id = activation["chip_id"]
            
            # 2. Atualiza a ativação
            requests.patch(f"{SUPABASE_URL}/rest/v1/activations?id=eq.{act_id}", json={"sms_code": texto, "status": "received", "updated_at": "now()"}, headers=headers)
            
            # 3. Libera o chip
            requests.patch(f"{SUPABASE_URL}/rest/v1/chips?id=eq.{chip_id}", json={"status": "idle"}, headers=headers)
            
            print(f"  ☁️  [CLOUD] SMS entregue para ativação {act_id[:8]}")
            return True
        else:
            print(f"  ☁️  [CLOUD] SMS recebido para {numero}, mas nenhuma ativação pendente encontrada.")
            return False
            
    except Exception as e:
        print(f"  ⚠️  [CLOUD] Erro de rede ao sincronizar SMS: {e}")
        return False

def set_all_offline():
    """Define este_polo como offline."""
    global _current_polo_id
    if not _current_polo_id or not SUPABASE_URL: return
    
    try:
        headers = get_headers()
        requests.patch(f"{SUPABASE_URL}/rest/v1/polos?id=eq.{_current_polo_id}", json={"status": "OFFLINE", "chips_ativos": 0}, headers=headers)
        print("  ☁️  [CLOUD] Polo setado como OFFLINE")
    except: pass
