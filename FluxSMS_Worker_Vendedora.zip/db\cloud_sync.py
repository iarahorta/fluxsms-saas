import os
import time
from supabase import create_client, Client
from dotenv import load_dotenv

# Carrega variáveis de ambiente
load_dotenv()

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_SERVICE_KEY") # Usamos service_key para bypassar RLS e gerenciar hardware

_supabase: Client = None

def get_supabase():
    global _supabase
    if _supabase is None:
        if not SUPABASE_URL or not SUPABASE_KEY:
            return None
        _supabase = create_client(SUPABASE_URL, SUPABASE_KEY)
    return _supabase

_current_polo_id = None

def init_polo(chave):
    global _current_polo_id
    supabase = get_supabase()
    if not supabase: return False
    
    try:
        # Busca o polo pela chave
        res = supabase.table("polos").select("id").eq("chave_acesso", chave).execute()
        if res.data and len(res.data) > 0:
            _current_polo_id = res.data[0]["id"]
            # Atualiza status e ultima comunicação
            supabase.table("polos").update({
                "status": "ONLINE",
                "ultima_comunicacao": "now()"
            }).eq("id", _current_polo_id).execute()
            return True
        return False
    except Exception as e:
        print(f"⚠️ Erro ao authenticar polo: {e}")
        return False

def sync_chip_to_cloud(porta, numero, operadora):
    """Sincroniza o status do chip local (polo) com o banco de dados na nuvem."""
    global _current_polo_id
    supabase = get_supabase()
    if not supabase or not _current_polo_id: return

    try:
        # Busca se já existe o chip neste polo para esta porta
        res = supabase.table("chips_fisicos").select("*").eq("polo_id", _current_polo_id).eq("porta_com", porta).execute()
        
        data = {
            "polo_id": _current_polo_id,
            "porta_com": porta,
            "numero_telefone": numero,
            "operadora": operadora,
            "bloqueado": False,
            "ultima_verificacao": "now()"
        }

        if res.data:
            supabase.table("chips_fisicos").update(data).eq("id", res.data[0]["id"]).execute()
        else:
            supabase.table("chips_fisicos").insert(data).execute()
            
        print(f"  ☁️  [CLOUD] Chip {numero} sincronizado (Porta: {porta})")
    except Exception as e:
        print(f"  ⚠️  [CLOUD] Erro ao sincronizar chip: {e}")

def sync_sms_to_cloud(numero, texto):
    """Envia o SMS recebido para a ativação pendente no Supabase."""
    supabase = get_supabase()
    if not supabase: return

    try:
        # 1. Busca a ativação mais recente 'waiting' para este número
        res = supabase.table("activations").select("*").eq("phone_number", numero).eq("status", "waiting").order("created_at", desc=True).limit(1).execute()
        
        if res.data:
            activation = res.data[0]
            # 2. Atualiza a ativação com o texto/código
            supabase.table("activations").update({
                "sms_code": texto,
                "status": "received",
                "updated_at": "now()"
            }).eq("id", activation["id"]).execute()
            
            # 3. Libera o chip para o próximo uso
            supabase.table("chips").update({"status": "idle"}).eq("id", activation["chip_id"]).execute()
            
            print(f"  ☁️  [CLOUD] SMS entregue para ativação {activation['id'][:8]}")
            return True
        else:
            print(f"  ☁️  [CLOUD] SMS recebido para {numero}, mas nenhuma ativação pendente encontrada.")
            return False
    except Exception as e:
        print(f"  ⚠️  [CLOUD] Erro ao sincronizar SMS: {e}")
        return False

def set_all_offline():
    """Define este_polo como offline."""
    global _current_polo_id
    supabase = get_supabase()
    if not supabase or not _current_polo_id: return
    try:
        supabase.table("polos").update({"status": "OFFLINE", "chips_ativos": 0}).eq("id", _current_polo_id).execute()
        print("  ☁️  [CLOUD] Todos os chips definidos como OFFLINE")
    except: pass
